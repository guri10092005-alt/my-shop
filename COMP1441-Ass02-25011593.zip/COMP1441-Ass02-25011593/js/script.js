let form = document.querySelector(".form");

if (form) {
form.addEventListener("submit", function(e) {
e.preventDefault();

let name = document.getElementById("fullname").value;
let email = document.getElementById("email").value;
let postcode = document.getElementById("postcode").value;

let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
let postcodePattern = /^[A-Za-z0-9 ]{4,10}$/;

if (name.length < 2) {
alert("Name must be at least 2 characters");
return;
}

if (!email.match(emailPattern)) {
alert("Enter a valid email");
return;
}

if (!postcode.match(postcodePattern)) {
alert("Enter a valid postcode");
return;
}

let modal = document.getElementById("modal");
if (modal) {
modal.style.display = "flex";
}
});
}



let savedTheme = localStorage.getItem("theme");

if (savedTheme === "dark") {
    document.body.classList.add("dark");
}

let themeBtn = document.getElementById("themeBtn");

if (themeBtn) {
    themeBtn.addEventListener("click", function() {
        document.body.classList.toggle("dark");

        if (document.body.classList.contains("dark")) {
            localStorage.setItem("theme", "dark");
        } else {
            localStorage.setItem("theme", "light");
        }
    });
}

let productList = document.getElementById("productList");

if (productList) {

let products = [
{
name: "Brown Shoes",
price: "£19.99",
image: "media/p1.jpg",
desc: "Comfortable brown shoes suitable for everyday wear",
link: "product.html#p1"
},
{
name: "Red Dress",
price: "£29.99",
image: "media/p2.jpg",
desc: "A simple red dress designed for casual or formal occasions",
link: "product.html#p2"
},
{
name: "Headphones",
price: "£45.99",
image: "media/p3.jpg",
desc: "White over-ear headphones with a clean and modern design",
link: "product.html#p3"
},
{
name: "Book",
price: "£7.99",
image: "media/p4.jpg",
desc: "A hardback book with a classic red and yellow cover design",
link: "product.html#p4"
}
];

productList.innerHTML = "";

products.forEach(function(product) {

let card = document.createElement("div");
card.classList.add("card");

card.innerHTML = `
<img src="${product.image}" alt="${product.name}">
<h3>${product.name}</h3>
<p>${product.price}</p>
<p>${product.desc}</p>
<a class="btn" href="${product.link}">View details</a>
`;

productList.appendChild(card);
});
}

let slideImage = document.getElementById("slideImage");

if (slideImage) {

let images = [
"media/p1.jpg",
"media/p2.jpg",
"media/p3.jpg",
"media/p4.jpg"
];

let index = 0;

let nextBtn = document.getElementById("nextBtn");
let prevBtn = document.getElementById("prevBtn");

nextBtn.addEventListener("click", function() {
index++;
if (index >= images.length) {
index = 0;
}
slideImage.src = images[index];
});

prevBtn.addEventListener("click", function() {
index--;
if (index < 0) {
index = images.length - 1;
}
slideImage.src = images[index];
});
}
let closeModal = document.getElementById("closeModal");

if (closeModal) {
closeModal.addEventListener("click", function() {
document.getElementById("modal").style.display = "none";

let form = document.querySelector(".form");
if (form) {
form.reset();
}
});
}